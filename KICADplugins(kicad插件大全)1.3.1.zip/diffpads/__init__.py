from .diffpads_plugin import DiffPadsPlugin
DiffPadsPlugin().register()
