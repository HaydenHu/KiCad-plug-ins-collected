# Diffpairs

This is a KiCAD plugin intended to create nice differential exits from pads
which are not rigourusly aligned to a 45 degrees line; e.g. Ethernet connectors
or PCIe connectors.

## Installation

Drop in the KiCAD plugin directory. It can also be run from the terminal with:

    python diffpads_cli.py <source file> <destination file>

Note the UI (both TUI and GUI) are very crude, staying in line with the user
unfriendlyness of KiCAD.

## Screens

Before (best I could do by hand) and after.

![versus](https://github.com/Tuetuopay/diffpads/raw/master/screens/comparison.png)

## License?

BeerWare.

Great, now I have to pay myself a drink.
