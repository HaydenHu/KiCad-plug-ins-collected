from .action_menu_pcb2dxf import pcb2dxf
pcb2dxf().register()
