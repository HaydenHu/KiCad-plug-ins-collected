from .snap2grid import snap_to_grid
snap_to_grid().register()
