from .annular_checker import annular_check
annular_check().register()
