from .fabrication_positions import generatePOS
generatePOS().register()
