from .text_tool_action import TextToolAction
TextToolAction().register()