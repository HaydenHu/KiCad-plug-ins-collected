from .settings_dialog import SettingsDialog, GeneralSettingsPanel
