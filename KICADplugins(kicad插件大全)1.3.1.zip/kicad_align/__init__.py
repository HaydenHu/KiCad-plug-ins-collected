from .kicad_align_action import *

AlignHorizontal().register() # Instantiate and register to Pcbnew
AlignVertical().register() # Instantiate and register to Pcbnew
