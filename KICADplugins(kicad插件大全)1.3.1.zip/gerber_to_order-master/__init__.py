from .gerber_to_order_action import GerberToOrderAction
GerberToOrderAction().register()
