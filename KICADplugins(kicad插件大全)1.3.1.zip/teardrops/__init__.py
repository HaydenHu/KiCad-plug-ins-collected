from .teardrop_plugin import TeardropPlugin
TeardropPlugin().register()
