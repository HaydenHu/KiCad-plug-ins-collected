from __future__ import print_function
import pprint
import traceback
import sys

print("Starting plugin flexRoundingSuite")
try:
    from .teardrop import *
	teardrop.generate()
    from . padTeardrop import *
    padTeardrop.generate()
    from .roundTracks import *
	roundTracks.rounder()
except Exception as e:
    traceback.print_exc(file=sys.stdout)
    pprint.pprint(e)