# kicad-plugin-arrange-like-schematic

Copy to `.kicad_plugins`.

Arranges components as they appear in the schematic to aid initial layout.