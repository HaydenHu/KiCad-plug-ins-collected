from .mesh_plugin import MeshPlugin

plugin = MeshPlugin()
plugin.register()
