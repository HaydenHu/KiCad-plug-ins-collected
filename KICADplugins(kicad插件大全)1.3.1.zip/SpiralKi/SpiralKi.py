import pcbnew
import os

class SpiralKi(pcbnew.ActionPlugin):
    def defaults(self):
        self.name = "SpiralKi 1.0"
        self.category = "Artistic PCBs"
        self.description = "generate a KiCad footprint (module) for spiral inductors on the PCB"
        self.show_toolbar_button = True # Optional, defaults to False
        self.icon_file_name = os.path.join(os.path.dirname(__file__), 'spiki.png') # Optional, defaults to ""

    def Run(self):
        # The entry function of the plugin that is executed on user action
        board = pcbnew.GetBoard()
        tracks = board.GetTracks()
        
       
        pcbnew.Refresh()

    

SpiralKi().register() # Instantiate and register to Pcbnew
